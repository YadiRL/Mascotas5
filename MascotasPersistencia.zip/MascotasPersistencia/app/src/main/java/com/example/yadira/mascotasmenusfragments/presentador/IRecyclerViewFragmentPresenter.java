package com.example.yadira.mascotasmenusfragments.presentador;

/**
 * Created by fcarvajal on 6/3/2017.
 */

public interface IRecyclerViewFragmentPresenter {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotasRecyclerView();

}
